"""
Battle Cats Save Editor
=======================
A Python library for reading and modifying Battle Cats save files.
"""

__version__ = "1.0.0"
__author__ = "Your Name"
