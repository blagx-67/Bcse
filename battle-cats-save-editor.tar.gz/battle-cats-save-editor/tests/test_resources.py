"""
tests/test_resources.py
------------------------
Unit tests for the ResourceEditor module.
Run with: pytest tests/
"""

import pytest
import struct
from unittest.mock import MagicMock

from editor.resources import ResourceEditor, OFFSETS


def make_mock_save(size: int = 0x2000) -> MagicMock:
    """Create a mock SaveFile with a real bytearray backing it."""
    data = bytearray(size)
    save = MagicMock()
    save._decrypted = True
    save.data = data

    def read_int(offset, size=4, signed=False):
        raw = bytes(data[offset:offset+size])
        return int.from_bytes(raw, "little", signed=signed)

    def write_int(offset, value, size=4, signed=False):
        data[offset:offset+size] = value.to_bytes(size, "little", signed=signed)

    save.read_int.side_effect = read_int
    save.write_int.side_effect = write_int
    return save


class TestResourceEditor:
    def setup_method(self):
        self.save = make_mock_save()
        self.res = ResourceEditor(self.save)

    def test_set_and_get_catfood(self):
        self.res.set_catfood(12345)
        assert self.res.get_catfood() == 12345

    def test_catfood_clamped_to_max(self):
        self.res.set_catfood(9_999_999)
        assert self.res.get_catfood() == 99_999

    def test_set_and_get_xp(self):
        self.res.set_xp(5_000_000)
        assert self.res.get_xp() == 5_000_000

    def test_set_rare_tickets(self):
        self.res.set_rare_tickets(500)
        assert self.res.get_rare_tickets() == 500

    def test_set_platinum_tickets(self):
        self.res.set_platinum_tickets(10)
        assert self.res.get_platinum_tickets() == 10

    def test_set_battle_item(self):
        self.res.set_battle_item(0, 50)
        assert self.res.get_battle_item(0) == 50

    def test_invalid_battle_item_index(self):
        with pytest.raises(ValueError):
            self.res.set_battle_item(99, 10)

    def test_max_resources(self):
        self.res.max_resources()
        assert self.res.get_catfood() == 99_999
        assert self.res.get_xp() == 9_999_999

    def test_summary_returns_string(self):
        result = self.res.summary()
        assert "Cat Food" in result
        assert "XP" in result
