"""
tests/test_units.py
-------------------
Unit tests for the UnitEditor module.
"""

import pytest
from unittest.mock import MagicMock

from editor.units import UnitEditor, CAT_ARRAY_OFFSET, CAT_ENTRY_SIZE


def make_mock_save(size: int = 0x10000) -> MagicMock:
    data = bytearray(size)
    save = MagicMock()
    save._decrypted = True
    save.data = data

    def read_int(offset, size=4, signed=False):
        raw = bytes(data[offset:offset+size])
        return int.from_bytes(raw, "little", signed=signed)

    def write_int(offset, value, size=4, signed=False):
        data[offset:offset+size] = value.to_bytes(size, "little", signed=signed)

    save.read_int.side_effect = read_int
    save.write_int.side_effect = write_int
    return save


class TestUnitEditor:
    def setup_method(self):
        self.save = make_mock_save()
        self.units = UnitEditor(self.save)

    def test_unlock_cat(self):
        self.units.unlock_cat(0)
        assert self.units.is_unlocked(0)

    def test_lock_cat(self):
        self.units.unlock_cat(5)
        self.units.lock_cat(5)
        assert not self.units.is_unlocked(5)

    def test_set_cat_level(self):
        self.units.unlock_cat(25)
        self.units.set_cat_level(25, level=20, plus_level=50)
        assert self.units.get_level(25) == 20
        assert self.units.get_plus_level(25) == 50

    def test_level_clamped(self):
        self.units.set_cat_level(0, level=999, plus_level=999)
        assert self.units.get_level(0) <= 60
        assert self.units.get_plus_level(0) <= 90

    def test_set_true_form(self):
        self.units.unlock_cat(10)
        self.units.set_true_form(10)
        assert self.units.get_form(10) == 2

    def test_invalid_cat_id(self):
        with pytest.raises(ValueError):
            self.units.unlock_cat(9999)

    def test_unlock_all_basic_cats(self):
        self.units.unlock_all_basic_cats()
        for i in range(27):
            assert self.units.is_unlocked(i)

    def test_get_cat_name_fallback(self):
        name = self.units.get_cat_name(9999)
        assert "9999" in name
